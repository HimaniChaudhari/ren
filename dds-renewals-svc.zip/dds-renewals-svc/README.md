# Java Microservice for Renewal Report

## Description:
* In this service fetching renewal/non-renewal data from datalake DB based on date range and report type from portal.

## API Provided by this service
* Renewal Report service - /dds-renewals/api/v1/reports

## Compile, Build and Run
* mvn clean install ---> Creates the jar
* mvn spring-boot:run -Dspring-boot.run.jvmArguments="-DEAPI_DEV_DB_PASSWORD={replace password}" ---> build and run

## Docker Build
If you want to build the image locally,
* Make sure you have built the application
* docker build -t shaic01/shaicapi:renewal-report-svc --build-arg ENV_PROP=DEV .

Mostly, docker image creation would happen from Jenkins pipeline
## Swagger UI
* Make sure you have run the application successfully
* Local ENV - [Access Here](http://localhost:8080/swagger-ui.html)
* For DEV, SIT and UAT env, add the correct domain name.