package com.sh;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class RenewalReportVoSvcApplication extends CSLSpringBootApplication {

	public static void main(String[] args) {
		configureApplication(new SpringApplicationBuilder()).run(args);
	}
	private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
		builder.sources(RenewalReportVoSvcApplication.class);
		initBase(builder, "renewal-report-vo-svc");
		return builder;
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return configureApplication(builder);
	}
}
