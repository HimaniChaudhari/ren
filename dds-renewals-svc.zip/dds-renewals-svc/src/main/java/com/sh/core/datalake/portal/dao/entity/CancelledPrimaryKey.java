package com.sh.core.datalake.portal.dao.entity;

import javax.persistence.Column;
import java.io.Serializable;

public class CancelledPrimaryKey implements Serializable {

    @Column(name = "policy_number", nullable = false)
    private String policyNumber;
}
