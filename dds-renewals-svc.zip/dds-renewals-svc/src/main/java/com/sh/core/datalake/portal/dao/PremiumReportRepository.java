package com.sh.core.datalake.portal.dao;

import com.sh.core.datalake.portal.dao.entity.RenewalReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
//import java.sql.Date;


@Repository
public interface PremiumReportRepository extends JpaRepository<RenewalReportEntity,String>{
    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.fulfiller_code = :fullFillerCode \n" +
                    "and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportFulfi(String renewStatus, String fullFillerCode, Date startDate, Date endDate );

    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.fulfiller_code = :fullFillerCode \n" +
                    "and policy_number =:policyNumber and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportFulfiAndPolicyNo(String renewStatus, String fullFillerCode,String policyNumber, Date startDate, Date endDate );

    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.fulfiller_code = :fullFillerCode \n" +
                    "and assured_name =:assuredName and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportFulfiAndAssuredName(String renewStatus, String fullFillerCode,String assuredName, Date startDate, Date endDate );

    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.fulfiller_code = :fullFillerCode \n" +
                    "and arrd.policy_number =:policyNumber and arrd.assured_name =:assuredName and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportFulfiAndPolicyNoAndAssuredName(String renewStatus, String fullFillerCode, String policyNumber, String assuredName, Date startDate, Date endDate );

    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.intermediary_code = :intermediaryCode \n" +
                    "and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportInter(String renewStatus, String intermediaryCode, Date startDate, Date endDate );


    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.intermediary_code = :intermediaryCode \n" +
                    "and arrd.policy_number =:policyNumber and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportInterAndPoilcyNo(String renewStatus, String intermediaryCode,String policyNumber, Date startDate, Date endDate );


    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.intermediary_code = :intermediaryCode \n" +
                    "and arrd.assured_name =:assuredName and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportInterAndAssuredName(String renewStatus, String intermediaryCode,String assuredName, Date startDate, Date endDate );

    @Query(
            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status = :renewStatus and arrd.intermediary_code = :intermediaryCode \n" +
                    "and arrd.policy_number =:policyNumber and arrd.assured_name =:assuredName and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
            nativeQuery = true)
    RenewalPremiumsReport getTotalRenewedReportInterAndPolicyNoAndAssuredName(String renewStatus, String intermediaryCode,String policyNumber,String assuredName, Date startDate, Date endDate );


//    @Query(
//            value = "select count(*) as totalCount, sum(arrd.current_premium_total) as totalPremium ,policy_renew_status as policyStatus \n" +
//                    "from agg_renewal_report_daily arrd where arrd.policy_renew_status (:renewStatus,:renewStatus) and arrd.intermediary_code = :intermediaryCode \n" +
//                    "and arrd.policy_number =:policyNumber and arrd.policy_to_date between :startDate and :endDate group by policy_renew_status ;",
//            nativeQuery = true)
//    RenewalPremiumsReport getTotalAllRenewedReportInterAndPoilcyNo(List<String> renewStatus, String intermediaryCode, String policyNumber, Date startDate, Date endDate );

}
