package com.sh.core.datalake.portal.dao.entity;

import lombok.*;

import javax.persistence.*;
import java.sql.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(value = RenewalPrimaryKey.class)
@Table(name="agg_renewal_report_daily", schema = "public")
public class UpsellReportEntity {
    @Id
    @Column(name ="policy_number")
    private String policyNumber;
    @Id
    @Column(name ="new_policy_number")
    private String newPolicyNumber;
    @Column(name ="assured_name")
    private String assuredName;
    @Column(name ="insured_name")
    private String insuredName;
    @Column(name ="telephone_no")
    private String telephoneNo;
    @Column(name ="email_id_old")
    private String emailId;
    @Column(name ="address_old")
    private String address;
    @Column(name ="intermediary_code")
    private String intermediaryCode;
    @Column(name ="intermediary_name")
    private String intermediaryName;
    @Column(name ="no_of_members_old")
    private String noOfMembers;
    @Column(name ="current_product")
    private String planName;
    @Column(name ="current_premium_base")
    private Integer currentPremiumBase;
    @Column(name ="current_sum_insured")
    private Integer currentSumInsured;
    @Column(name ="current_premium_tax")
    private Integer currentPremiumTax;
    @Column(name ="current_premium_total")
    private Integer currentPremiumTotal;
    @Column(name ="new_premium_base")
    private Integer newPremiumBase;
    @Column(name ="new_sum_insured")
    private Integer newSumInsured;
    @Column(name ="new_premium_tax")
    private Integer newPremiumTax;
    @Column(name ="new_premium_total")
    private Integer newPremiumTotal;
    @Column(name ="current_policy_issue_date")
    private Date currentPolicyIssueDate;
    @Column(name ="current_policy_expiry_date")
    private Date currentPolicyExpiryDate;
    @Column(name ="claim_flag")
    private String claimFlag;
    @Column(name ="claim_settlement_amount")
    private Integer claimSettlementAmount;
    @Column(name ="policy_to_date")
    private Date policyToDate;
    @Column(name ="upsell_flag")
    private String upsellFlag;
    @Column(name ="fulfiller_code")
    private String fullFillerCode;
}
