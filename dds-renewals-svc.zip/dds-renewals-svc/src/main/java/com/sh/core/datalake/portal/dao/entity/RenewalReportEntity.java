package com.sh.core.datalake.portal.dao.entity;


import lombok.*;

import javax.persistence.*;
import java.sql.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(value = RenewalPrimaryKey.class)
@Table(name="agg_renewal_report_daily", schema = "public")
public class RenewalReportEntity {
    @Id
    @Column(name ="policy_number")
    private String policyNumber;
    @Id
    @Column(name ="new_policy_number")
    private String newPolicyNumber;
    @Column(name ="assured_name")
    private String assuredName;
    @Column(name ="policy_from_date")
    private Date policyFromDate;
    @Column(name ="policy_to_date")
    private Date policyToDate;
    @Column(name ="insured_name")
    private String insuredName;
    @Column(name ="telephone_no")
    private String telephoneNo;
    @Column(name ="current_premium_base")
    private Integer premiumOld;
    @Column(name ="fulfiller_code")
    private String fullFillerCode;
    @Column(name ="fulfiller_name")
    private String fullFillerName;
    @Column(name ="policy_renew_status")
    private String policyStatus;
    @Column(name ="new_product")
    private String newProduct;
    @Column(name ="new_premium_base")
    private Integer premiumNew;
    @Column(name ="current_sum_insured")
    private Integer sumInsuredOld;
    @Column(name ="new_sum_insured")
    private Integer sumInsuredNew;
    @Column(name ="current_premium_tax")
    private Integer gstOld;
    @Column(name ="new_premium_tax")
    private Integer gstNew;
    @Column(name ="current_premium_total")
    private String premiumTotalOld;
    @Column(name ="new_premium_total")
    private String premiumTotalNew;
    @Column(name ="intermediary_code")
    private String intermediaryCode;
    @Column(name ="intermediary_name")
    private String intermediaryName;
    @Column(name ="claim_flag")
    private String claimFlag;
    @Column(name ="current_product")
    private String planName;
    @Column(name ="address_old")
    private String addressOld;
    @Column(name ="address_new")
    private String addressNew;
    @Column(name ="email_id_old")
    private String emailIdOld;
    @Column(name ="email_id_new")
    private String emailIdNew;
    @Column(name ="no_of_members_old")
    private String noOfMembersOld;
    @Column(name ="no_of_members_new")
    private String noOfMembersNew;
}