package com.sh.core.datalake.portal.dao;

import com.sh.core.datalake.portal.dao.entity.UpsellReportEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface UpsellReportRepository extends JpaRepository <UpsellReportEntity,String>{
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlag(String fullFillerCode, Date startDate, Date endDate, String upsellFlag, Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlag(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanName(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String planName,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanName(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String planName,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredNameAndPolicyNumber(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String planName,String assuredName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredNameAndPolicyNumber(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String planName,String assuredName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndPolicyNumber(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String planName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndPolicyNumber(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String planName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredName(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String planName,String assuredName,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredName(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String planName,String assuredName,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredNameAndPolicyNumber(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String assuredName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredNameAndPolicyNumber(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String assuredName,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPolicyNumber(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPolicyNumber(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String policyNumber,Pageable pageable);
    Page<UpsellReportEntity> findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredName(String fullFillerCode, Date startDate, Date endDate, String upsellFlag,String assuredName,Pageable pageable);
    Page<UpsellReportEntity> findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredName(String intermediaryCode, Date startDate, Date endDate, String upsellFlag,String assuredName,Pageable pageable);
}

