package com.sh.core.datalake.portal.dao.entity;


import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(value = CancelledPrimaryKey.class)
@Table(name="agg_cancelled_policy", schema = "public")
public class CancelledReportEntity {
    @Id
    @Column(name ="policy_number")
    private String policyNumber;
    @Column(name ="web_aggregator_code")
    private String webAggregatorCode;
    @Column(name ="intermediary_code")
    private String intermediaryCode;
    @Column(name ="intermediary_name")
    private String intermediaryName;
    @Column(name ="insured_name")
    private String insuredName;
    @Column(name ="assured_name")
    private String assuredName;
    @Column(name ="telephone_no")
    private String telephoneNo;
    @Column(name ="product_code")
    private String productCode;
    @Column(name ="product_name")
    private String productName;
    @Column(name ="premium")
    private Integer premiumTotalOld;
    @Column(name ="agent_code")
    private String agentCode;
    @Column(name ="fulfiller_code")
    private String fullFillerCode;
    @Column(name ="fulfiller_name")
    private String fullFillerName;
    @Column(name ="sp_code")
    private String spCode;
    @Column(name ="sp_name")
    private String spName;
    @Column(name ="pol_cancellation_date")
    private Timestamp policyCancellationDate;
    @Column(name = "remarks")
    private String remarks;
}