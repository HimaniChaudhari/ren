package com.sh.core.datalake.portal.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface RenewalPremiumsReport {

    Long getTotalCount();
    BigDecimal getTotalPremium();
    Optional<String> getPolicyStatus();
}
