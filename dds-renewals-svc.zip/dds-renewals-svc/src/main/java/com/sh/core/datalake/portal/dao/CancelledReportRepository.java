package com.sh.core.datalake.portal.dao;

import com.sh.core.datalake.portal.dao.entity.CancelledReportEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;

@Repository
public interface CancelledReportRepository extends JpaRepository<CancelledReportEntity, String> {
    Page<CancelledReportEntity> findByFullFillerCodeAndPolicyCancellationDateBetween(String fullFillerCode, Timestamp startDate, Timestamp endDate, Pageable pageable);
    Page<CancelledReportEntity> findByIntermediaryCodeAndPolicyCancellationDateBetween(String intermediaryCode,Timestamp startDate, Timestamp endDate, Pageable pageable);
    Page<CancelledReportEntity> findByFullFillerCodeAndPolicyCancellationDateBetweenAndAssuredNameAndPolicyNumber(String fullFillerCode, Timestamp startDate, Timestamp endDate, String assuredName,String policyNumber,Pageable pageable);
    Page<CancelledReportEntity> findByIntermediaryCodeAndPolicyCancellationDateBetweenAndAssuredNameAndPolicyNumber(String intermediaryCode,Timestamp startDate, Timestamp endDate, String assuredName,String policyNumber,Pageable pageable);
    Page<CancelledReportEntity> findByFullFillerCodeAndPolicyCancellationDateBetweenAndPolicyNumber(String fullFillerCode, Timestamp startDate, Timestamp endDate, String policyNumber,Pageable pageable);
    Page<CancelledReportEntity> findByIntermediaryCodeAndPolicyCancellationDateBetweenAndPolicyNumber(String intermediaryCode,Timestamp startDate, Timestamp endDate, String policyNumber,Pageable pageable);
    Page<CancelledReportEntity> findByFullFillerCodeAndPolicyCancellationDateBetweenAndAssuredName(String fullFillerCode, Timestamp startDate, Timestamp endDate,String assuredName, Pageable pageable);
    Page<CancelledReportEntity> findByIntermediaryCodeAndPolicyCancellationDateBetweenAndAssuredName(String intermediaryCode,Timestamp startDate, Timestamp endDate, String assuredName,Pageable pageable);

}
