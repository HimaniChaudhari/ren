package com.sh.core.datalake.portal.dao;

import com.sh.core.datalake.portal.dao.entity.RenewalReportEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface RenewalReportJpaRepository extends JpaRepository<RenewalReportEntity,String> {

    Page<RenewalReportEntity> findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetween(String renewStatus, String fulFillerCode, Date startDate, Date endDate, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetween(String renewStatus,String intermediaryCode,Date startDate,Date endDate,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(String renewStatus, String fulFillerCode, Date startDate, Date endDate, String assuredName, String policyNumber, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(String renewStatus,String intermediaryCode,Date startDate,Date endDate,String assuredName,String policyNumber,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndPolicyNumber(String renewStatus,String intermediaryCode,Date startDate,Date endDate,String policyNumber,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredName(String renewStatus,String intermediaryCode,Date startDate,Date endDate,String assuredName,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndPolicyNumber(String renewStatus, String fulFillerCode, Date startDate, Date endDate, String policyNumber, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndAssuredName(String renewStatus, String fulFillerCode, Date startDate, Date endDate, String assuredName, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetween(List<String> renewStatus, String fulFillerCode, Date startDate, Date endDate, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetween(List<String> renewStatus,String intermediaryCode,Date startDate,Date endDate,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(List<String> renewStatus, String fulFillerCode, Date startDate, Date endDate, String assuredName, String policyNumber, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(List<String> renewStatus,String intermediaryCode,Date startDate,Date endDate,String assuredName,String policyNumber,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndPolicyNumber(List<String> renewStatus,String intermediaryCode,Date startDate,Date endDate,String policyNumber,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredName(List<String> renewStatus,String intermediaryCode,Date startDate,Date endDate,String assuredName,Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndPolicyNumber(List<String> renewStatus, String fulFillerCode, Date startDate, Date endDate, String policyNumber, Pageable pageable);

    Page<RenewalReportEntity> findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndAssuredName(List<String> renewStatus, String fulFillerCode, Date startDate, Date endDate, String assuredName, Pageable pageable);
}
