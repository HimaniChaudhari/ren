package com.sh.api.renewal.utils;

import com.sh.base.core.util.YmlPropertyLoader;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.Map;

@Data
@Configuration
@ConfigurationProperties(prefix = "renewal.service")
@PropertySource(value = "classpath:renewal-report-config.yml", factory = YmlPropertyLoader.class)
public class RenewalReportTemplateConfig {
    private Map<String, String> templates;
}
