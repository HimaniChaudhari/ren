package com.sh.api.renewal.utils;

public final class TemplateConstants {
    private TemplateConstants(){

    }
    public static final String RENEWAL_REPORT_RES_TEMPLATE = "getRenewalReportRes";
    public static final String CANCELLED_REPORT_RES_TEMPLATE = "getCancelledReportRes";
    public static final String UPSELL_REPORT_RES_TEMPLATE = "getUpsellReportRes";
}

