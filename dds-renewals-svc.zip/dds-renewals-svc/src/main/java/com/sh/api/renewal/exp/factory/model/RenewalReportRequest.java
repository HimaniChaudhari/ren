package com.sh.api.renewal.exp.factory.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sh.api.renewal.sys.config.RenewalReportConstants;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RenewalReportRequest {
    @JsonProperty(value = "report_type")
    @NotEmpty(message = RenewalReportConstants.REPORT_TYPE_NOT_BLANK_OR_EMPTY)
    private String reportType;
    @NotBlank(message = RenewalReportConstants.START_DATE_NOT_BLANK_OR_EMPTY)
    @Pattern(regexp = RenewalReportConstants.INPUT_DATE_PATTERN, message = RenewalReportConstants.INPUT_DATE_PATTERN_MESSAGE)
    @JsonProperty(value = "start_date", required = true)
    private String startDate;
    @NotBlank(message = RenewalReportConstants.END_DATE_NOT_BLANK_OR_EMPTY)
    @Pattern(regexp = RenewalReportConstants.INPUT_DATE_PATTERN, message = RenewalReportConstants.INPUT_DATE_PATTERN_MESSAGE)
    @JsonProperty(value = "end_date", required = true)
    private String endDate;
    @NotEmpty(message = RenewalReportConstants.AGENT_CODE_NOT_BLANK_OR_EMPTY)
    @JsonProperty(value = "agent_code", required = true)
    private String agentCode;
    @NotEmpty(message = RenewalReportConstants.PERSONA_NOT_BLANK_OR_EMPTY)
    @Pattern(regexp = "^[A-Z]+$", message = RenewalReportConstants.PERSONA_PATTERN_CAPITAL)
    @JsonProperty(value = "persona" , required = true)
    private String persona;
    @JsonProperty(value = "product_code")
    private String productCode;
    @JsonProperty(value = "page_size", required = true)
    private int pageSize;
    @JsonProperty(value = "page_number", required = true)
    private int pageNumber;
    @JsonProperty(value = "search_criteria")
    private SearchCriteria searchCriteria;
}
