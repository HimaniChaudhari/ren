package com.sh.api.renewal.sys.service;

import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;
import com.sh.api.renewal.sys.service.vo.*;

public interface RenewalReportService {
    public RenewalReportResponse getRenewalRenewedDetails (RenewalReportRequest renewalReportRequest);
}
