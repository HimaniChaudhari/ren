package com.sh.api.renewal.exp.factory;

import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;
import com.sh.api.renewal.sys.config.RenewalReportConstants;
import com.sh.api.renewal.sys.service.RenewalReportService;
import com.sh.api.renewal.sys.service.vo.*;
import com.sh.api.renewal.utils.RenewalReportTemplateConfig;
import com.sh.api.renewal.utils.TemplateConstants;
import com.sh.base.core.exception.util.CSLErrorCodes;
import com.sh.base.core.util.ExceptionHandlerUtils;
import com.sh.base.core.util.FreeMarkerConvertor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service
public class RenewalReportFactoryImpl implements RenewalReportFactory {
    @Autowired
    private RenewalReportService renewalReportService;
    @Autowired
    private FreeMarkerConvertor freeMarkerConvertor;
    @Autowired
    private RenewalReportTemplateConfig templateConfig;

    @Override
    public String getRenewalRenewedReport(RenewalReportRequest renewalReportRequest) {
        log.debug("Inside RenewalReportFactoryImpl ::" + renewalReportRequest);
        RenewalReportResponse renewalRenewedResponse = null;
        String response = null;
        String responseTemplate = null;
        try {
            if (!StringUtils.isEmpty(renewalReportRequest.getReportType())) {
                switch (renewalReportRequest.getReportType()) {
                    case RenewalReportConstants.REPORT_TYPE_REN:
                        renewalReportRequest.setReportType(RenewalReportConstants.POLICY_RENEWED_STATUS);
                        break;
                    case RenewalReportConstants.REPORT_TYPE_NON_REN:
                        renewalReportRequest.setReportType(RenewalReportConstants.POLICY_NON_RENEWED_STATUS);
                        break;
                    case RenewalReportConstants.REPORT_TYPE_REN_NON_REN:
                        renewalReportRequest.setReportType(RenewalReportConstants.REPORT_TYPE_ALL);
                        break;
                    case RenewalReportConstants.REPORT_TYPE_CANCELLED:
                        renewalReportRequest.setReportType(RenewalReportConstants.REPORT_TYPE_CANCELLED);
                        break;
                    case RenewalReportConstants.REPORT_TYPE_UPSELL:
                        break;
                    default:
                        log.debug("Invalid renewal status");
                        renewalReportRequest.setReportType(null);
                        break;
                }
            }

            if (renewalReportRequest.getPageNumber() == 0) {
                renewalReportRequest.setPageNumber(1);
            }
            if (renewalReportRequest.getPageSize() == 0) {
                renewalReportRequest.setPageSize(RenewalReportConstants.DEFAULT_PAGE_SIZE);
            }
            renewalRenewedResponse = renewalReportService.getRenewalRenewedDetails(renewalReportRequest);
            if (!StringUtils.isEmpty(renewalReportRequest.getReportType()) && renewalReportRequest.getReportType().equals(RenewalReportConstants.REPORT_TYPE_CANCELLED)) {
                responseTemplate = templateConfig.getTemplates().get(TemplateConstants.CANCELLED_REPORT_RES_TEMPLATE);
            } else if (!StringUtils.isEmpty(renewalReportRequest.getReportType()) && renewalReportRequest.getReportType().equals(RenewalReportConstants.REPORT_TYPE_UPSELL)) {
                responseTemplate = templateConfig.getTemplates().get(TemplateConstants.UPSELL_REPORT_RES_TEMPLATE);
            } else {
                responseTemplate = templateConfig.getTemplates().get(TemplateConstants.RENEWAL_REPORT_RES_TEMPLATE);
            }
            response = freeMarkerConvertor.convertDataMapToPayload(responseTemplate, renewalRenewedResponse);
        } catch (Exception ex) {
            log.error("There was a problem while processing request to getRenewalRenewedDetails", ex);
            ExceptionHandlerUtils.handleException(ex, CSLErrorCodes.DEFAULT_ERROR_CODE);
        }
        return response;
    }
}