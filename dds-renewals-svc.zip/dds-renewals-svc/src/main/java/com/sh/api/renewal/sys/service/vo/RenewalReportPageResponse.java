package com.sh.api.renewal.sys.service.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RenewalReportPageResponse {
    @JsonProperty( "total_count")
    private long totalCount;
    @JsonProperty( "total_pages")
    private int totalPages;
    @JsonProperty( "current_page")
    private int currentPage;
    @JsonProperty( "total_premium")
    private BigDecimal totalPremium;
    @JsonProperty( "total_premium_renewed")
    private BigDecimal totalPremiumRenewed;
    @JsonProperty( "total_premium_not_renewed")
    private BigDecimal totalPremiumNotRenewed;
    @JsonProperty( "total_count_renewed")
    private long totalCountRenewed;
    @JsonProperty( "total_count_not_renewed")
    private long totalCountNotRenewed;
    @JsonProperty("renewalRenewedVO")
    private List<RenewalReportVO> renewalRenewedVOList;
}
