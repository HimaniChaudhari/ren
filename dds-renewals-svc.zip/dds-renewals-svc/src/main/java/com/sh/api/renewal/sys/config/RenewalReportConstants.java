package com.sh.api.renewal.sys.config;

public class RenewalReportConstants {

    private RenewalReportConstants() {
    }

    public static final String REPORT_TYPE_REN = "REN";
    public static final String POLICY_RENEWED_STATUS = "RENEWED";
    public static final String REPORT_TYPE_NON_REN = "NON-REN";
    public static final String REPORT_TYPE_ALL = "ALL";
    public static final String POLICY_NON_RENEWED_STATUS = "NOT_RENEWED";
    public static final String REPORT_TYPE_REN_NON_REN = "REN_NON-REN";
    public static final String REPORT_TYPE_CANCELLED = "CANCELLED";
    public static final String REPORT_TYPE_UPSELL = "UPSELL";
    public static final String UPSELL_FLAG = "Y";
    public static final String PERSONA_FULFI = "FULFI";
    public static final String FULFILLER_CODE = "fulfiller_code";
    public static final String INTERMEDIARY_CODE = "intermediary_code";
    public static final String POLICY_NUMBER = "policy_number";
    public static final String ASSURED_NAME = "assured_name";
    public static final String PLAN_NAME = "plan_name";
    public static final String PERSONA_NOT_BLANK_OR_EMPTY = "Persona must not be blank or empty";
    public static final String PERSONA_PATTERN_CAPITAL = "Persona must be in Capital Letters";

    public static final String REPORT_TYPE_NOT_BLANK_OR_EMPTY = "Report type must not be blank or empty";
    public static final String START_DATE_NOT_BLANK_OR_EMPTY = "Start Date must not be blank or empty";
    public static final String END_DATE_NOT_BLANK_OR_EMPTY = "End Date must not be blank or empty";

    public static final String AGENT_CODE_NOT_BLANK_OR_EMPTY = "Agent code must not be blank or empty";
    public static final String AGENT_CODE_SIZE = "Agent code value should be 7 to 12 character";
    public static final String INPUT_DATE_PATTERN = "^(0[0-9]||1[0-2])/([0-2][0-9]||3[0-1])/([0-9][0-9])?[0-9][0-9]$";
    public static final String INPUT_DATE_PATTERN_MESSAGE = "Start date or end date must be in MM/dd/yyyy format";
    public static final int DEFAULT_PAGE_SIZE = 50;

}
