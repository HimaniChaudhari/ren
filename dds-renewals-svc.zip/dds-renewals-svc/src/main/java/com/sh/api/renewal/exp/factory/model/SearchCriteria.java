package com.sh.api.renewal.exp.factory.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sh.api.renewal.sys.config.RenewalReportConstants;
import lombok.Data;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchCriteria {
    @JsonProperty(value = "policy_number", required = false)
    private String policyNumber;
    @JsonProperty(value = "customer_name", required = false)
    private String customerName;
}
