package com.sh.api.renewal.sys.service;

import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;
import com.sh.api.renewal.sys.config.RenewalReportConstants;
import com.sh.api.renewal.sys.service.vo.RenewalReportPageResponse;
import com.sh.api.renewal.sys.service.vo.RenewalReportResponse;
import com.sh.api.renewal.sys.service.vo.RenewalReportVO;
import com.sh.base.core.exception.TechnicalException;
import com.sh.base.core.exception.util.CSLErrorCodes;
import com.sh.base.core.util.AuditLogUtils;
import com.sh.base.core.util.ExceptionHandlerUtils;
import com.sh.core.datalake.portal.dao.CancelledReportRepository;
import com.sh.core.datalake.portal.dao.PremiumReportRepository;
import com.sh.core.datalake.portal.dao.RenewalReportJpaRepository;
import com.sh.core.datalake.portal.dao.UpsellReportRepository;
import com.sh.core.datalake.portal.dao.entity.CancelledReportEntity;
import com.sh.core.datalake.portal.dao.RenewalPremiumsReport;
import com.sh.core.datalake.portal.dao.entity.RenewalReportEntity;
import com.sh.core.datalake.portal.dao.entity.UpsellReportEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;


import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static com.sh.api.renewal.sys.config.RenewalReportConstants.*;

@Slf4j
@Service
public class RenewalReportServiceImpl implements RenewalReportService {
    private final SimpleDateFormat requestDateFormat = new SimpleDateFormat("MM/dd/yyyy");
    @Autowired
    private CancelledReportRepository cancelledReportRepository;
    @Autowired
    private RenewalReportJpaRepository renewalReportJpaRepository;
    @Autowired
    private UpsellReportRepository upsellReportRepository;
    @Autowired
    private PremiumReportRepository premiumReportRepository;

    @Override
    @Transactional
    public RenewalReportResponse getRenewalRenewedDetails(RenewalReportRequest renewalReportRequest) {
        log.info("RenewalReportRequest :: getRenewalRenewedDetails");

        List<Object> renewalList = new ArrayList<>();
        String renewStatus = REPORT_TYPE_ALL;
        String fulFillerCode = null;
        String intermediaryCode = null;
        String policyNumber = null;
        String assuredName = null;

        try {
            Date parsedEndDate = requestDateFormat.parse(renewalReportRequest.getEndDate());
            Date parsedStartDate = requestDateFormat.parse(renewalReportRequest.getStartDate());
            Date startDate = new java.sql.Date(parsedStartDate.getTime());
            Date endDate = new java.sql.Date(parsedEndDate.getTime());
            Timestamp tStartDate = new Timestamp(startDate.getTime());
            Timestamp tEndDate = new Timestamp(endDate.getTime());
            int currentPage = renewalReportRequest.getPageNumber();
            Pageable pageable = PageRequest.of(renewalReportRequest.getPageNumber() - 1, renewalReportRequest.getPageSize());

            if (!StringUtils.isEmpty(renewalReportRequest.getReportType())) {
                if (renewalReportRequest.getReportType().equals(REPORT_TYPE_ALL)) {
                    renewStatus = renewalReportRequest.getReportType();
                    renewalList.add(renewalReportRequest.getReportType());
                } else {
                    renewalList.add(renewalReportRequest.getReportType());
                    renewStatus = renewalReportRequest.getReportType();
                }
            }
            if (renewalReportRequest.getPersona().equals(RenewalReportConstants.PERSONA_FULFI)) {
                renewalList.add(FULFILLER_CODE);
                fulFillerCode = renewalReportRequest.getAgentCode();
            } else {
                renewalList.add(INTERMEDIARY_CODE);
                intermediaryCode = renewalReportRequest.getAgentCode();
            }
            if (!StringUtils.isEmpty(renewalReportRequest.getSearchCriteria().getPolicyNumber())) {
                policyNumber = renewalReportRequest.getSearchCriteria().getPolicyNumber();
                renewalList.add(POLICY_NUMBER);
            }
            if (!StringUtils.isEmpty(renewalReportRequest.getSearchCriteria().getCustomerName())) {
                assuredName = renewalReportRequest.getSearchCriteria().getCustomerName();
                renewalList.add(ASSURED_NAME);
            }

            switch (renewStatus) {
                case REPORT_TYPE_ALL:
                    return getAllRenewalStatusResponse(renewalList,currentPage,fulFillerCode,intermediaryCode,assuredName,policyNumber,startDate,endDate,pageable);
                case POLICY_RENEWED_STATUS:
                case POLICY_NON_RENEWED_STATUS:
                    return getRenewedNonRenewedReport(renewalList, renewStatus, fulFillerCode, intermediaryCode, startDate, endDate, pageable, renewalReportRequest, policyNumber, assuredName);
                case REPORT_TYPE_CANCELLED:
                    return cancelledReport(renewalList, tStartDate, tEndDate, fulFillerCode, intermediaryCode, assuredName, policyNumber, pageable, renewalReportRequest);
                case REPORT_TYPE_UPSELL:
                    return upsellReport(renewalList, startDate, endDate, fulFillerCode, intermediaryCode, assuredName, policyNumber, pageable, renewalReportRequest);
                default:
                    log.info("No response");
                    return null;
            }

        } catch (Exception e) {
            log.error("Exception Occurred: {}", e.getMessage());
            throw new TechnicalException(e);
        }
    }

    private RenewalReportResponse cancelledReport(List<Object> renewalList, Timestamp startDate, Timestamp endDate, String fulfillerCode, String intermediaryCode, String assuredName, String policyNumber, Pageable pageable, RenewalReportRequest renewalReportRequest) {
        Page<CancelledReportEntity> cancelledPageResponse = Page.empty();
        try {
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByFullFillerCodeAndPolicyCancellationDateBetween(fulfillerCode, startDate, endDate, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByIntermediaryCodeAndPolicyCancellationDateBetween(intermediaryCode, startDate, endDate, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByFullFillerCodeAndPolicyCancellationDateBetweenAndAssuredNameAndPolicyNumber(fulfillerCode, startDate, endDate, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByIntermediaryCodeAndPolicyCancellationDateBetweenAndAssuredNameAndPolicyNumber(intermediaryCode, startDate, endDate, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByFullFillerCodeAndPolicyCancellationDateBetweenAndPolicyNumber(fulfillerCode, startDate, endDate, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByIntermediaryCodeAndPolicyCancellationDateBetweenAndPolicyNumber(intermediaryCode, startDate, endDate, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByFullFillerCodeAndPolicyCancellationDateBetweenAndAssuredName(fulfillerCode, startDate, endDate, assuredName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                cancelledPageResponse = cancelledReportRepository.findByIntermediaryCodeAndPolicyCancellationDateBetweenAndAssuredName(intermediaryCode, startDate, endDate, assuredName, pageable);
            }
            List<RenewalReportVO> cancelledReportVOList = getCancelledReportDetails(cancelledPageResponse);
            BigDecimal totalPremium = null;
            return setFinalResponse(cancelledPageResponse.getTotalPages(), cancelledPageResponse.getTotalElements(), renewalReportRequest.getPageNumber(), cancelledReportVOList, REPORT_TYPE_CANCELLED,totalPremium);
        } catch (Exception ex) {
            log.error(ExceptionUtils.getStackTrace(ex));
            ExceptionHandlerUtils.handleException(ex, CSLErrorCodes.DEFAULT_ERROR_CODE);
        }
        return null;
    }

    private List<RenewalReportVO> getCancelledReportDetails(Page<CancelledReportEntity> cancelledPageResponse) {
        return cancelledPageResponse.getContent().stream()
                .map(entity -> {
                    RenewalReportVO renewalReportVO = new RenewalReportVO();
                    BeanUtils.copyProperties(entity, renewalReportVO);
                    return renewalReportVO;
                })
                .collect(Collectors.toList());
    }

    private RenewalReportResponse getAllRenewalStatusResponse(List<Object> renewalList, int currentPage, String fulFillerCode, String intermediaryCode, String assuredName, String policyNumber, Date startDate, Date endDate, Pageable pageable) {
        List<String> renewalAllStatus = Arrays.asList(POLICY_RENEWED_STATUS,POLICY_NON_RENEWED_STATUS);
        Page<RenewalReportEntity> results = Page.empty();
        RenewalPremiumsReport results2 = null;
        RenewalPremiumsReport results3 = null;

        BigDecimal bd1 = BigDecimal.ZERO;
        BigDecimal bd2 = BigDecimal.ZERO;

        if (renewalList.contains(FULFILLER_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetween(renewalAllStatus, fulFillerCode, startDate, endDate, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportFulfi(POLICY_RENEWED_STATUS, fulFillerCode, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportFulfi(POLICY_NON_RENEWED_STATUS, fulFillerCode, startDate, endDate);
        }
        if (renewalList.contains(INTERMEDIARY_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetween(renewalAllStatus, intermediaryCode, startDate, endDate, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportInter(POLICY_RENEWED_STATUS, intermediaryCode, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportInter(POLICY_NON_RENEWED_STATUS, intermediaryCode, startDate, endDate);
        }
        if (renewalList.contains(FULFILLER_CODE) && renewalList.contains(POLICY_NUMBER) && renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(renewalAllStatus, fulFillerCode, startDate, endDate, assuredName, policyNumber, pageable);
                Optional<RenewalPremiumsReport> renewalPremiumsReport1 = Optional.ofNullable(premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNoAndAssuredName(POLICY_RENEWED_STATUS, fulFillerCode, policyNumber, assuredName, startDate, endDate));
            if(renewalPremiumsReport1.isPresent()){
                bd1=renewalPremiumsReport1.get().getTotalPremium();
            }
            Optional<RenewalPremiumsReport> renewalPremiumsReport2 = Optional.ofNullable(premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNoAndAssuredName(POLICY_NON_RENEWED_STATUS, fulFillerCode,policyNumber,assuredName, startDate, endDate));
            if(renewalPremiumsReport2.isPresent()){
                bd2=renewalPremiumsReport2.get().getTotalPremium();
            }
        }
        if (renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(POLICY_NUMBER) && renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(renewalAllStatus, intermediaryCode, startDate, endDate, assuredName, policyNumber, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportInterAndPolicyNoAndAssuredName(POLICY_RENEWED_STATUS, intermediaryCode,policyNumber,assuredName, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportInterAndPolicyNoAndAssuredName(POLICY_NON_RENEWED_STATUS, intermediaryCode,policyNumber,assuredName, startDate, endDate);
        }
        if (renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndPolicyNumber(renewalAllStatus, intermediaryCode, startDate, endDate, policyNumber, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportInterAndPoilcyNo(POLICY_RENEWED_STATUS, intermediaryCode,policyNumber, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportInterAndPoilcyNo(POLICY_NON_RENEWED_STATUS, intermediaryCode,policyNumber, startDate, endDate);
        }
        if (renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(ASSURED_NAME) && !renewalList.contains(POLICY_NUMBER)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredName(renewalAllStatus, intermediaryCode, startDate, endDate, assuredName, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportInterAndAssuredName(POLICY_RENEWED_STATUS, intermediaryCode,assuredName, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportInterAndAssuredName(POLICY_NON_RENEWED_STATUS, intermediaryCode,assuredName, startDate, endDate);
        }
        if (renewalList.contains(FULFILLER_CODE) && renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndPolicyNumber(renewalAllStatus, fulFillerCode, startDate, endDate, policyNumber, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNo(POLICY_RENEWED_STATUS, fulFillerCode,policyNumber, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNo(POLICY_NON_RENEWED_STATUS, fulFillerCode,policyNumber, startDate, endDate);
        }
        if (renewalList.contains(FULFILLER_CODE) && renewalList.contains(ASSURED_NAME) && !renewalList.contains(POLICY_NUMBER)) {
            results = renewalReportJpaRepository.findByPolicyStatusIsInAndFullFillerCodeAndPolicyToDateBetweenAndAssuredName(renewalAllStatus, fulFillerCode, startDate, endDate, assuredName, pageable);
            results2 = premiumReportRepository.getTotalRenewedReportFulfiAndAssuredName(POLICY_RENEWED_STATUS, fulFillerCode,assuredName, startDate, endDate);
            results3 = premiumReportRepository.getTotalRenewedReportFulfiAndAssuredName(POLICY_NON_RENEWED_STATUS, fulFillerCode,assuredName, startDate, endDate);
        }
        List<RenewalReportVO> allRenewalReport = setRenewalReportResponse(results);

        BigDecimal totalPremium = bd1.add(bd2);
        //BigDecimal totalPremium = results2.getTotalPremium().add(results3.getTotalPremium());
        return setAllFinalResponse(results.getTotalPages(), results.getTotalElements(), currentPage, allRenewalReport, REPORT_TYPE_ALL,totalPremium,results2.getTotalCount(),results3.getTotalCount(),results2.getTotalPremium(),results3.getTotalPremium());
    }

    public List<RenewalReportVO> setRenewalReportResponse(Page<RenewalReportEntity> results) {
        return results.stream()
                .map(entity -> {
                    RenewalReportVO renewalRenewedVO = new RenewalReportVO();
                    BeanUtils.copyProperties(entity, renewalRenewedVO);
                    if(entity.getPolicyStatus().equals(POLICY_RENEWED_STATUS)) {
                        renewalRenewedVO.setSumInsured(entity.getSumInsuredNew());
                    } else if(entity.getPolicyStatus().equals(POLICY_NON_RENEWED_STATUS)) {
                        renewalRenewedVO.setSumInsured(entity.getSumInsuredOld());
                    }
                    renewalRenewedVO.setPolicyFromDate(requestDateFormat.format(entity.getPolicyFromDate()));
                    renewalRenewedVO.setPolicyToDate(requestDateFormat.format(entity.getPolicyToDate()));
                    renewalRenewedVO.setPremiumTotal( BigDecimal.valueOf(Double.parseDouble(entity.getPremiumTotalOld())+Double.parseDouble(entity.getPremiumTotalNew())));
                    renewalRenewedVO.setAddress(getValue(entity.getAddressNew(), entity.getAddressOld()).map(Object::toString).orElse(null));
                    renewalRenewedVO.setEmailId(getValue(entity.getEmailIdNew(), entity.getEmailIdOld()).map(Object::toString).orElse(null));
                    renewalRenewedVO.setNoOfMembers(getValue(entity.getNoOfMembersNew(), entity.getNoOfMembersOld()).map(Object::toString).orElse(null));
                    return renewalRenewedVO;
                })
                .collect(Collectors.toList());
    }

    private Optional<Object> getValue(Object param1, Object param2) {
        Optional<Object> value = !StringUtils.isEmpty(param2) ? Optional.of(param2) : Optional.empty();
        return !StringUtils.isEmpty(param1) ? Optional.of(param1) : value;
    }

    private RenewalReportResponse setFinalResponse(int totalPages, long totalCount, int currentPage, List<RenewalReportVO> reports, String reportType , BigDecimal totalPremium) {
        RenewalReportResponse renewalReportResponse = new RenewalReportResponse();
        RenewalReportPageResponse renewalReportPageResponse = new RenewalReportPageResponse();
        switch (reportType) {
            case POLICY_RENEWED_STATUS:
                renewalReportPageResponse.setTotalCount(totalCount);
                renewalReportPageResponse.setTotalPremium(totalPremium);
                renewalReportPageResponse.setTotalCountRenewed(totalCount);
                renewalReportPageResponse.setTotalPremiumRenewed(totalPremium);
                break;
            case POLICY_NON_RENEWED_STATUS:
                renewalReportPageResponse.setTotalCount(totalCount);
                renewalReportPageResponse.setTotalPremium(totalPremium);
                renewalReportPageResponse.setTotalCountNotRenewed(totalCount);
                renewalReportPageResponse.setTotalPremiumNotRenewed(totalPremium);
                break;
            default:
                log.debug("Total premium calculation not required for {}", reportType);
        }
        renewalReportPageResponse.setTotalPages(totalPages);
        renewalReportPageResponse.setTotalCount(totalCount);
        renewalReportPageResponse.setCurrentPage(currentPage);
        renewalReportPageResponse.setRenewalRenewedVOList(reports);
        renewalReportResponse.setRequestUID(MDC.get(AuditLogUtils.REQUEST_ID));
        renewalReportResponse.setRenewalRenewedPageResponse(renewalReportPageResponse);
        return renewalReportResponse;
    }

    private RenewalReportResponse setAllFinalResponse(int totalPages, long totalCount, int currentPage, List<RenewalReportVO> reports, String reportType , BigDecimal totalPremium , long totalCountRen , long totalCountNonRen ,BigDecimal PremiumRen, BigDecimal PremiumNonRen ) {
        RenewalReportResponse renewalReportResponse = new RenewalReportResponse();
        RenewalReportPageResponse renewalReportPageResponse = new RenewalReportPageResponse();
        switch (reportType) {
            case REPORT_TYPE_ALL:
                renewalReportPageResponse.setTotalPremium(totalPremium);
                renewalReportPageResponse.setTotalCount(totalCount);
                renewalReportPageResponse.setTotalCountRenewed(totalCountRen);
                renewalReportPageResponse.setTotalPremiumRenewed(PremiumRen);
                renewalReportPageResponse.setTotalCountNotRenewed(totalCountNonRen);
                renewalReportPageResponse.setTotalPremiumNotRenewed(PremiumNonRen);
                break;
            default:
                log.debug("Total premium calculation not required for {}", reportType);
        }
        renewalReportPageResponse.setTotalPages(totalPages);
        renewalReportPageResponse.setCurrentPage(currentPage);
        renewalReportPageResponse.setRenewalRenewedVOList(reports);
        renewalReportResponse.setRequestUID(MDC.get(AuditLogUtils.REQUEST_ID));
        renewalReportResponse.setRenewalRenewedPageResponse(renewalReportPageResponse);
        return renewalReportResponse;
    }

    private RenewalReportResponse getRenewedNonRenewedReport(List<Object> renewalList, String renewStatus, String fulFillerCode, String intermediaryCode, Date startDate, Date endDate, Pageable pageable, RenewalReportRequest renewalReportRequest, String policyNumber, String assuredName) {
        int currentPage = renewalReportRequest.getPageNumber();
        Page<RenewalReportEntity> results = Page.empty();
        RenewalPremiumsReport results2 = null;
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(FULFILLER_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetween(renewStatus, fulFillerCode, startDate, endDate, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfi(renewStatus, fulFillerCode, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfi(renewStatus, fulFillerCode, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(INTERMEDIARY_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetween(renewStatus, intermediaryCode, startDate, endDate, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInter(renewStatus, intermediaryCode, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInter(renewStatus, intermediaryCode, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(FULFILLER_CODE) && renewalList.contains(POLICY_NUMBER) && renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(renewStatus, fulFillerCode, startDate, endDate, assuredName, policyNumber, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                //results2 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNoAndAssuredName(renewStatus, fulFillerCode,policyNumber,assuredName, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                //results2 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNoAndAssuredName(renewStatus, fulFillerCode,policyNumber,assuredName, startDate, endDate);
            }}
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(POLICY_NUMBER) && renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredNameAndPolicyNumber(renewStatus, intermediaryCode, startDate, endDate, assuredName, policyNumber, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndPolicyNoAndAssuredName(renewStatus, intermediaryCode,policyNumber,assuredName, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndPolicyNoAndAssuredName(renewStatus, intermediaryCode,policyNumber,assuredName, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndPolicyNumber(renewStatus, intermediaryCode, startDate, endDate, policyNumber, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndPoilcyNo(renewStatus, intermediaryCode,policyNumber, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndPoilcyNo(renewStatus, intermediaryCode,policyNumber, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(INTERMEDIARY_CODE) && renewalList.contains(ASSURED_NAME) && !renewalList.contains(POLICY_NUMBER)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndIntermediaryCodeAndPolicyToDateBetweenAndAssuredName(renewStatus, intermediaryCode, startDate, endDate, assuredName, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndAssuredName(renewStatus, intermediaryCode,assuredName, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportInterAndAssuredName(renewStatus, intermediaryCode,assuredName, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(FULFILLER_CODE) && renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndPolicyNumber(renewStatus, fulFillerCode, startDate, endDate, policyNumber, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNo(renewStatus, fulFillerCode,policyNumber, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfiAndPolicyNo(renewStatus, fulFillerCode,policyNumber, startDate, endDate);
            }
        }
        if ((renewalList.contains(POLICY_RENEWED_STATUS) || renewalList.contains(POLICY_NON_RENEWED_STATUS)) && renewalList.contains(FULFILLER_CODE) && renewalList.contains(ASSURED_NAME) && !renewalList.contains(POLICY_NUMBER)) {
            results = renewalReportJpaRepository.findByPolicyStatusAndFullFillerCodeAndPolicyToDateBetweenAndAssuredName(renewStatus, fulFillerCode, startDate, endDate, assuredName, pageable);
            if (renewalList.contains(POLICY_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfiAndAssuredName(renewStatus, fulFillerCode,assuredName, startDate, endDate);
            }
            if (renewalList.contains(POLICY_NON_RENEWED_STATUS)) {
                results2 = premiumReportRepository.getTotalRenewedReportFulfiAndAssuredName(renewStatus, fulFillerCode,assuredName, startDate, endDate);
            }
        }

        List<RenewalReportVO> renewalReports = setRenewalReportResponse(results);
        BigDecimal totalPremium = results2.getTotalPremium();

        return setFinalResponse(results.getTotalPages(), results.getTotalElements(), currentPage, renewalReports, renewStatus , totalPremium);
    }

    private RenewalReportResponse upsellReport(List<Object> renewalList, Date startDate, Date endDate, String fulfillerCode, String intermediaryCode, String assuredName, String policyNumber, Pageable pageable, RenewalReportRequest renewalReportRequest) {
        Page<UpsellReportEntity> upsellPageResponse = Page.empty();
        String upsellFlag = RenewalReportConstants.UPSELL_FLAG;
        String planName = null;
        if (!StringUtils.isEmpty(renewalReportRequest.getProductCode())) {
            planName = renewalReportRequest.getProductCode();
            renewalList.add(RenewalReportConstants.PLAN_NAME);
        }
        try {
            if (renewalList.contains(FULFILLER_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlag(fulfillerCode, startDate, endDate, upsellFlag, pageable);
            }
            if (renewalList.contains(INTERMEDIARY_CODE) && !renewalList.contains(POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlag(intermediaryCode, startDate, endDate, upsellFlag, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanName(fulfillerCode, startDate, endDate, upsellFlag, planName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanName(intermediaryCode, startDate, endDate, upsellFlag, planName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredNameAndPolicyNumber(fulfillerCode, startDate, endDate, upsellFlag, planName, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredNameAndPolicyNumber(intermediaryCode, startDate, endDate, upsellFlag, planName, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndPolicyNumber(fulfillerCode, startDate, endDate, upsellFlag, planName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndPolicyNumber(intermediaryCode, startDate, endDate, upsellFlag, planName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredName(fulfillerCode, startDate, endDate, upsellFlag, planName, assuredName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPlanNameAndAssuredName(intermediaryCode, startDate, endDate, upsellFlag, planName, assuredName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredNameAndPolicyNumber(fulfillerCode, startDate, endDate, upsellFlag, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredNameAndPolicyNumber(intermediaryCode, startDate, endDate, upsellFlag, assuredName, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndPolicyNumber(fulfillerCode, startDate, endDate, upsellFlag, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && !renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndPolicyNumber(intermediaryCode, startDate, endDate, upsellFlag, policyNumber, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.FULFILLER_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByFullFillerCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredName(fulfillerCode, startDate, endDate, upsellFlag, assuredName, pageable);
            }
            if (renewalList.contains(RenewalReportConstants.INTERMEDIARY_CODE) && !renewalList.contains(RenewalReportConstants.PLAN_NAME) && !renewalList.contains(RenewalReportConstants.POLICY_NUMBER) && renewalList.contains(RenewalReportConstants.ASSURED_NAME)) {
                upsellPageResponse = upsellReportRepository.findByIntermediaryCodeAndPolicyToDateBetweenAndUpsellFlagAndAssuredName(intermediaryCode, startDate, endDate, upsellFlag, assuredName, pageable);
            }
            BigDecimal totalPremium = null;
            return setFinalResponse(upsellPageResponse.getTotalPages(), upsellPageResponse.getTotalElements(), renewalReportRequest.getPageNumber(), getUpsellReportDetails(upsellPageResponse), REPORT_TYPE_UPSELL,totalPremium);
        } catch (Exception ex) {
            log.error(ExceptionUtils.getStackTrace(ex));
            ExceptionHandlerUtils.handleException(ex, CSLErrorCodes.DEFAULT_ERROR_CODE);
        }
        return null;
    }

    private List<RenewalReportVO> getUpsellReportDetails(Page<UpsellReportEntity> upsellPageResponse) {
        return upsellPageResponse.getContent().stream()
                .map(entity -> {
                    RenewalReportVO renewalReportVO = new RenewalReportVO();
                    BeanUtils.copyProperties(entity, renewalReportVO);
                    renewalReportVO.setCurrentPolicyIssueDate(requestDateFormat.format(entity.getCurrentPolicyIssueDate()));
                    renewalReportVO.setCurrentPolicyExpiryDate(requestDateFormat.format(entity.getCurrentPolicyExpiryDate()));
                    return renewalReportVO;
                })
                .collect(Collectors.toList());
    }




}
