package com.sh.api.renewal.exp.factory.config;

import com.google.gson.JsonObject;
import com.sh.base.auth.util.AuthConstants;
import lombok.val;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.List;

@EnableSwagger2
@Configuration
@Profile(value = {"DEV"})
public class SwaggerConfig implements WebMvcConfigurer {
    private static final String HEADER = "header";
    private static final String HEADER_TYPE = "string";
    @Value("${prop.swagger.enabled}")
    private boolean enableSwagger;

    @Bean
    public Docket postMatchApi() {

        return new Docket(DocumentationType.SWAGGER_2)
                .forCodeGeneration(true)
                .globalOperationParameters(globalParameterList())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.sh.api.renewal.exp.controller"))
                .paths(PathSelectors.ant("/**"))
                .build()
                .apiInfo(metaData())
                .enable(enableSwagger);
    }

    private ApiInfo metaData() {
        return new ApiInfoBuilder()
                .title("Star Health API Swagger Spec")
                .description("Renewal Report service. This microservice is used for fetch Renewal Report")
                .termsOfServiceUrl("https://help.starhealth.in/")
                .version("1.0")
                .license("(C) Star Health Copyright Test")
                .build();
    }

    private List<Parameter> globalParameterList() {
        //Adding Header
        val authTokenHeader =
                new ParameterBuilder()
                        .name(AuthConstants.AUTHORIZATION) // name of the header
                        .modelRef(new ModelRef(HEADER_TYPE)) // data-type of the header
                        .required(true) // required/optional
                        .parameterType(HEADER_TYPE) // for query-param, this value can be 'query'
                        .description("Basic Auth Token")
                        .build();
        val shClientContext =
                new ParameterBuilder()
                        .name(AuthConstants.SH_CLIENT_CONTEXT) // name of the header
                        .modelRef(new ModelRef(HEADER_TYPE)) // data-type of the header
                        .required(true) // required/optional
                        .parameterType(HEADER) // for query-param, this value can be 'query'
                        .description(clientContext())
                        .build();
        val reqUID =
                new ParameterBuilder()
                        .name(AuthConstants.REQUUID) // name of the header
                        .modelRef(new ModelRef(HEADER_TYPE)) // data-type of the header
                        .required(true) // required/optional
                        .parameterType(HEADER) // for query-param, this value can be 'query'
                        .description("unique requestUID")
                        .build();
        return Arrays.asList(authTokenHeader,reqUID,shClientContext);
    }

    String rumEvents = "\"rumEvents\": {" +
            " \"browserName\": \"chrome\"," +
            " \"browserVersion\": \"2.3\"," +
            " \"deviceName\": \"SH123LAP1\"," +
            " \"modelNo\": \"i13\"," +
            " \"osType\": \"iOS\"," +
            " \"osVersion\": \"123.123\"" +
            " }";
    private String clientContext(){
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty(AuthConstants.REQUUID,"cb790182-ff85-11ec-b939-0242ac120002");
        jsonObject.addProperty(AuthConstants.COUNTRY, "IN");
        jsonObject.addProperty(AuthConstants.CHANNEL, "1004");
        jsonObject.addProperty(AuthConstants.CLIENTIP, "10.2.3.10");
        jsonObject.addProperty(AuthConstants.LANG, "EN");
        jsonObject.addProperty(AuthConstants.SRCSYSTEM, "Virtual Office");
        jsonObject.addProperty(AuthConstants.SRCSCHANNELID, "WEB");
        jsonObject.addProperty(AuthConstants.RUMEVENTS, rumEvents);
        return  jsonObject.toString();
    }
}
