package com.sh.api.renewal.exp.controller;

import com.sh.api.renewal.exp.factory.RenewalReportFactory;
import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;
import com.sh.api.renewal.sys.config.RenewalReportConstants;
import com.sh.base.core.aspects.BasicAuth;
import com.sh.base.core.log.LogTimeTaken;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/dds-renewals/api/v1/renewals")
@Api(tags = "Renewal Report Service")
public class RenewalReportController {

    @Autowired
    private RenewalReportFactory renewalReportFactory;

    @ApiOperation(httpMethod = "POST", response = String.class, value = "Get renewal reports")
    @ApiResponses(value = {@io.swagger.annotations.ApiResponse(code = 200, message = "OK"),
            @io.swagger.annotations.ApiResponse(code = 400, message = "Bad Request"),
            @io.swagger.annotations.ApiResponse(code = 401, message = "Unauthorized"),
            @io.swagger.annotations.ApiResponse(code = 404, message = "Not Found"),
            @io.swagger.annotations.ApiResponse(code = 500, message = "Internal Server Error."),
            @io.swagger.annotations.ApiResponse(code = 503, message = "Service Unavailable")})
    //@BasicAuth
    @LogTimeTaken
    @PostMapping(value = "/reports", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getRenewalReport(@Validated @RequestBody RenewalReportRequest renewalReportRequest) {
        log.debug("Inside Renewal Report Controller ");
        String response = null;
        response = renewalReportFactory.getRenewalRenewedReport(renewalReportRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
