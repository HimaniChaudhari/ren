package com.sh.api.renewal.sys.service.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RenewalReportVO {
    @JsonProperty( "assured_name")
    private String assuredName;
    @JsonProperty( "policy_number")
    private String policyNumber;
    @JsonProperty( "intermediary_code")
    private String brokerCode;
    @JsonProperty( "policy_from_date")
    private String policyFromDate;
    @JsonProperty( "policy_to_date")
    private String policyToDate;
    @JsonProperty( "insured_name")
    private String insuredName;
    @JsonProperty( "telephone_no")
    private String telephoneNo;
    @JsonProperty( "current_product")
    private String planName;
    @JsonProperty( "premium")
    private Object premiumTotalOld;
    @JsonProperty( "fulfiller_code")
    private String fullFillerCode;
    @JsonProperty( "fulfiller_name")
    private String fullFillerName;
    @JsonProperty( "policy_status")
    private String policyStatus;
    @JsonProperty( "new_policy_number")
    private String newPolicyNumber;
    @JsonProperty( "new_product")
    private String newProduct;
    @JsonProperty( "new_premium")
    private Object premiumTotalNew;
    @JsonProperty( "sum_insured")
    private Object sumInsured;
    @JsonProperty( "gst")
    private Object gstNew;
    @JsonProperty( "premium_total_previous_plus_new")
    private BigDecimal premiumTotal;
    @JsonProperty( "intermediary_code")
    private String intermediaryCode;
    @JsonProperty( "intermediary_name")
    private String intermediaryName;
    @JsonProperty( "claim_flag")
    private String claimFlag;
    @JsonProperty( "occupation")
    private String occupation;
    @JsonProperty( "approved_status")
    private String approvedStatus;
    @JsonProperty( "address")
    private String address;
    @JsonProperty( "email_id")
    private String emailId;
    @JsonProperty( "no_of_members")
    private String noOfMembers;
    @JsonProperty("web_aggregator_code")
    private String webAggregatorCode;
    @JsonProperty("product_code")
    private String productCode;
    @JsonProperty("product_name")
    private String productName;
    @JsonProperty("agent_code")
    private String agentCode;
    @JsonProperty("sp_code")
    private String spCode;
    @JsonProperty("sp_name")
    private String spName;
    @JsonProperty("pol_cancellation_date")
    private String policyCancellationDate;
    @JsonProperty("reported_date")
    private String reportedDate;
    @JsonProperty("load_timestamp")
    private String loadTimestamp;
    @JsonProperty("telephone_no_enc")
    private String telephoneNoEnc;
    @JsonProperty("load_start_time")
    private String loadStartTime;
    @JsonProperty("remarks")
    private String remarks;
    @JsonProperty("current_premium_base")
    private BigDecimal currentPremiumBase;
    @JsonProperty("current_sum_insured")
    private Integer currentSumInsured;
    @JsonProperty("current_premium_tax")
    private Integer currentPremiumTax;
    @JsonProperty("current_premium_total")
    private Integer currentPremiumTotal;
    @JsonProperty("new_premium_base")
    private Integer newPremiumBase;
    @JsonProperty("new_sum_insured")
    private Integer newSumInsured;
    @JsonProperty("new_premium_tax")
    private Integer newPremiumTax;
    @JsonProperty("new_premium_total")
    private Integer newPremiumTotal;
    @JsonProperty("current_policy_issue_date")
    private String currentPolicyIssueDate;
    @JsonProperty("current_policy_expiry_date")
    private String currentPolicyExpiryDate;
    @JsonProperty("claim_settlement_amount")
    private Integer claimSettlementAmount;
}
