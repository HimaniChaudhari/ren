package com.sh.api.renewal.exp.factory;

import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;

public interface RenewalReportFactory {

    String getRenewalRenewedReport(RenewalReportRequest renewalReportRequest);
}
