
package com.sh.api.renewal.config;

import com.google.common.base.Preconditions;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
@Slf4j
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.sh.core.datalake.portal.dao", entityManagerFactoryRef = "portalDataLakeEntityManager", transactionManagerRef = "portalDataLakeTransactionManager")
public class PortalDatalakeDataSourceConfig {
    @Autowired
    private Environment env;

    public PortalDatalakeDataSourceConfig() {
        super();
    }

    @Bean(name = "portalDataLakeDataSource")
    public DataSource portalDataLakeDataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.jdbcUrl")));
        config.setDriverClassName(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.driverClassName")));
        config.setUsername(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.username")));
        config.setPassword(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.password")));
        config.setMaximumPoolSize(Integer.parseInt(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.maximumPoolSize"))));
        config.setConnectionTimeout(Long.parseLong(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.connectionTimeout"))));
        config.setIdleTimeout(Long.parseLong(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.idleTimeout"))));
        config.setMaxLifetime(Long.parseLong(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.maxLifetime"))));
        config.setLeakDetectionThreshold(Long.parseLong(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.leakDetectionThreshold"))));
        config.setMinimumIdle(Integer.parseInt(Preconditions.checkNotNull(this.env.getProperty("spring.portal-datalake.datasource.hikari.minimumIdle"))));
        return new HikariDataSource(config);
    }

    @Bean(name = "portalDataLakeEntityManager")
    public LocalContainerEntityManagerFactoryBean portalDatalakeEntityManager(EntityManagerFactoryBuilder builder,
                                                                              @Qualifier("portalDataLakeDataSource") DataSource portalDataLakeDataSource) {
        final LocalContainerEntityManagerFactoryBean em = builder.dataSource(portalDataLakeDataSource)
                .packages("com.sh.core.datalake.portal.dao.entity")
                .build();
        final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        final HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.portal-datalake.jpa.hibernate.ddl-auto"));
        properties.put("hibernate.dialect", env.getProperty("spring.portal-datalake.jpa.properties.hibernate.dialect"));
        properties.put("hibernate.current_session_context_class", env.getProperty("spring.portal-datalake.jpa.properties.hibernate.current_session_context_class"));
        properties.put("hibernate.jdbc.lob.non_contextual_creation", env.getProperty("spring.portal-datalake.jpa.properties.hibernate.jdbc.lob.non_contextual_creation"));
        properties.put("hibernate.show_sql", env.getProperty("spring.portal-datalake.jpa.show-sql"));
        properties.put("hibernate.format_sql", env.getProperty("spring.portal-datalake.jpa.properties.hibernate.format_sql"));

        em.setJpaPropertyMap(properties);
        return em;
    }

    @Bean("portalDataLakeTransactionManager")
    public PlatformTransactionManager datalakeTransactionManager(final @Qualifier("portalDataLakeEntityManager") LocalContainerEntityManagerFactoryBean datalakeEntityManagerFactory) {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(datalakeEntityManagerFactory.getObject());
        return transactionManager;
    }
}

