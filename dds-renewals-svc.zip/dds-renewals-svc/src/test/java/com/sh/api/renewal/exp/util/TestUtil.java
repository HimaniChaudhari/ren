package com.sh.api.renewal.exp.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

@Slf4j
public class TestUtil {
    public static String API_DIR = "unit-test/";
    public static String RENEWAL_REPORT_REQUEST = API_DIR.concat("get-renewal-report-request.json");
    public static String RENEWAL_REPORT_RESPONSE = API_DIR.concat("get-renewal-report-response.json");
    public static String CANCELLED_REPORT_RESPONSE = API_DIR.concat("get-cancelled-report-response.json");
    public static String UPSELL_REPORT_RESPONSE = API_DIR.concat("get-upsell-report-response.json");

    public static String readFromFile(String fileName) {
        String fileContent = "";
        try {
            File file = ResourceUtils.getFile("classpath:" + fileName);
            fileContent = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        } catch (Exception e) {

        }
        return fileContent;
    }
}
