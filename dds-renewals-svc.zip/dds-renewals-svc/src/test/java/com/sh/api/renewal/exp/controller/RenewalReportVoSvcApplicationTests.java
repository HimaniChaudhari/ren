package com.sh.api.renewal.exp.controller;


import com.sh.api.renewal.exp.factory.model.RenewalReportRequest;
import com.sh.api.renewal.exp.util.TestUtil;
import com.sh.base.core.audit.service.APIAuditLogService;
import com.sh.base.core.exception.util.ResponseUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@WebMvcTest(RenewalReportController.class)
class RenewalReportVoSvcApplicationTests {
    @MockBean
    private APIAuditLogService apiAuditLogService;
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private RestTemplate restTemplate;
    @MockBean
    private RenewalReportController renewalReportController;
    @MockBean
    private ResponseUtil responseUtil;

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getRenewalReportTest() throws Exception {
        String URL = "/dds-renewals/api/v1/renewals/reports";
        String mockRequest = TestUtil.readFromFile(TestUtil.RENEWAL_REPORT_REQUEST);
        String mockResponse = TestUtil.readFromFile(TestUtil.RENEWAL_REPORT_RESPONSE);
        when(renewalReportController.getRenewalReport(any(RenewalReportRequest.class)))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(URL)
                .contentType(APPLICATION_JSON).content(mockRequest)
                .accept(APPLICATION_JSON)).andReturn();
        int status = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), status, ("Incorrect Response Status"));
        verify(renewalReportController).getRenewalReport(any(RenewalReportRequest.class));
        String response = result.getResponse().getContentAsString();
        Assertions.assertNotNull(response, "Mock Response is not found");
    }
    @Test
    void getCancelledReportTest() throws Exception {
        String URL = "/dds-renewals/api/v1/renewals/reports";
        String mockRequest = TestUtil.readFromFile(TestUtil.RENEWAL_REPORT_REQUEST);
        String mockResponse = TestUtil.readFromFile(TestUtil.CANCELLED_REPORT_RESPONSE);
        when(renewalReportController.getRenewalReport(any(RenewalReportRequest.class)))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(URL)
                .contentType(APPLICATION_JSON).content(mockRequest)
                .accept(APPLICATION_JSON)).andReturn();
        int status = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), status, ("Incorrect Response Status"));
        verify(renewalReportController).getRenewalReport(any(RenewalReportRequest.class));
        String response = result.getResponse().getContentAsString();
        Assertions.assertNotNull(response, "Mock Response is not found");
    }
    @Test
    void getUpsellReportTest() throws Exception {
        String URL = "/dds-renewals/api/v1/renewals/reports";
        String mockRequest = TestUtil.readFromFile(TestUtil.RENEWAL_REPORT_REQUEST);
        String mockResponse = TestUtil.readFromFile(TestUtil.UPSELL_REPORT_RESPONSE);
        when(renewalReportController.getRenewalReport(any(RenewalReportRequest.class)))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(URL)
                .contentType(APPLICATION_JSON).content(mockRequest)
                .accept(APPLICATION_JSON)).andReturn();
        int status = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), status, ("Incorrect Response Status"));
        verify(renewalReportController).getRenewalReport(any(RenewalReportRequest.class));
        String response = result.getResponse().getContentAsString();
        Assertions.assertNotNull(response, "Mock Response is not found");
    }
}
